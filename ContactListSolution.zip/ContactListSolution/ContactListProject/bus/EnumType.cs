﻿namespace ContactListProject.bus
{
    public enum EnumType
    {
        Family,
        Friend,
        Work,
        Other
    }
}
